package com.Ebays.pojo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ProductPage {

	private WebDriver driver;
	private By macBookLink=By.xpath("//span[contains(text(),'Apple Macbook Air 13 Laptop | i5 8GB + 512GB SSD |')]");
	
	public ProductPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement macLink() {
		return driver.findElement(macBookLink);
	}
	
}
