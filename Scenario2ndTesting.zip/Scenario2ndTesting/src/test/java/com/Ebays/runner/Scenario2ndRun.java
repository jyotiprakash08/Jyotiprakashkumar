package com.Ebays.runner;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

	@CucumberOptions(features= {"src/test/resources/feature/2ndScenario.feature"},
            glue={"com.Ebays.steps"})
	public class Scenario2ndRun extends AbstractTestNGCucumberTests{


}
