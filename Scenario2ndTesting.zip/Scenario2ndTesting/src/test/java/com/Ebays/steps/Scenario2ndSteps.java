package com.Ebays.steps;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.Ebays.base.BaseTest;

import com.Ebays.pojo.ProductPage;
import com.Ebays.pojo.HomePage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Scenario2ndSteps extends BaseTest {

	HomePage hp;
	ProductPage pp;
	
	
	@Given("^Initialize the browser with chrome$")
	public void initialize_the_browser_with_chrome() {
		init();
		driver.manage().window().maximize();		
	}
	
	@Given("^Navigate to \"([^\"]*)\" site$")
	public void navigate_to_site(String strArg) {
	driver.get(strArg);
	}
	
	@When("Navigate to search bar and type {string}")
	public void navigate_to_search_bar_and_type(String string) {
		hp=new HomePage(driver);
		hp.searchBar().click();
	    hp.searchBar().sendKeys(string);
	}
	
	@Then("Navigate to search by {string}")
	public void navigate_to_search_by(String string) {
		hp.categories().click();
		Select drpFilter=new Select(hp.categories());
		drpFilter.selectByVisibleText(string);
		hp.submit().click();
	 }
	
	@Then("verify page loads completely")
	public void verify_page_loads_completely() {
		System.out.println(driver.getCurrentUrl());
		Assert.assertTrue(driver.getCurrentUrl().equals("https://www.ebay.com/sch/i.html?_from=R40&_trksid=p4432023.m570.l1313&_nkw=MacBook&_sacat=58058"));
	}
	
	@Then("first result name matches with search string {string}")
	public void first_result_name_matches_with_search_string(String string) {
		
		pp=new ProductPage(driver);
		String mac=pp.macLink().getText();
		int beingIndex=mac.indexOf("Macbook");
		int lastIndex=mac.indexOf("Air");
		String word=mac.substring(beingIndex, lastIndex);
		Assert.assertEquals(word, string);
	}
	
}
